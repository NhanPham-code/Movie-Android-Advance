package com.example.ojtaadaassignment12.util;

public class Constant {
    public static final String IMAGE_BASE_URL = "https://image.tmdb.org/t/p/original";
}
